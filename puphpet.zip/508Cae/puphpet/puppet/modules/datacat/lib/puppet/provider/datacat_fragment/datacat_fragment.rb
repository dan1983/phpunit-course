Puppet::Type.type(:datacat_fragment).provide(:datacat_fragment) do
  mk_resource_methods
end
